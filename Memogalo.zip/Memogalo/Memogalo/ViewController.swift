//
//  ViewController.swift
//  Memogalo
//
//  Created by MultiLab PRT on 18/07/2023.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnIniciarLaunch(_ sender: Any) {
    }
    
}

